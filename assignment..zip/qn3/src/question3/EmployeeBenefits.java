/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question3;

import java.util.Scanner;
import java.util.TreeMap;

/**
 *
 * @author julo
 */
public class EmployeeBenefits {

    String name, surname;
    int code;
    double salary, newSalary;
    static TreeMap<String, Double> employees = new TreeMap<>();

    public void captureDetails() {
        Scanner in = new Scanner(System.in);//for getting input from the terminal
        System.out.println("Please enter the name");
        name = in.nextLine();
        System.out.println("Please enter the surname");
        surname = in.nextLine();
        System.out.println("Please enter the code");
        code = Integer.parseInt(in.nextLine());
        System.out.println("Please enter the salary");
        salary = Double.parseDouble(in.nextLine());

        this.setNewSalary();//set salary

        employees.put(getEmployeeNumber(), newSalary);//add employee to the map
    }

    public String getEmployeeNumber() {
        return code + name + surname;//combine code, name and surname
    }

    public void printDetails() {//print out the details
        System.out.println("Details before adjustiments:\n\t\t"
                + "name=" + name + " surname=" + surname + " code=" + code + " salary=" + salary);
    }

    public void setNewSalary() {
        if (salary < 8000) {//if salary is less than 8000
            newSalary = salary + salary * 0.103;//increment by 10.3%
        }
        if (salary < 15000) {//below 1500 but above 8000
            newSalary = salary + salary * 0.094;
        }
        if (salary > 15000) {//above 15000
            newSalary = salary + salary * 0.091;
        }
    }

    public void printDetailsAfterAdjustment() {//printoyt the employee details
        System.out.println("Details after adjustiments:\n\t\t"
                + "name=" + name + " surname=" + surname + " code=" + code + " salary=" + newSalary);
    }

    public static void main(String args[]) {
        boolean test = true;
        while (test) {//keep looping until the user says no
            EmployeeBenefits eb = new EmployeeBenefits();//
            eb.captureDetails();//capture employee details
            eb.printDetails();//print them
            eb.printDetailsAfterAdjustment();//adjudt them then print
            System.out.println("Do tou wish to continue? (Y/N)");
            if (new Scanner(System.in).nextLine().equalsIgnoreCase("y")) {//if user says 'y'
                test = true;//we continue
            } else {
                test = false;//otherwise we stop here!
            }
        }
    }

}
