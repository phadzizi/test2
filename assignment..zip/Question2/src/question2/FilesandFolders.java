/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question2;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;

/**
 *
 * @author user
 */
public class FilesandFolders {

    ArrayList<String> folders = new ArrayList<>();//list of folders
    ArrayList<String> files = new ArrayList<>();//list of files
    private HashSet<String> duplicates;//collection of duplicates

    public static void main(String... args) {
        new FilesandFolders();//instantiate FilesandFolders
    }
 
    ArrayList<String> listFiles() {//returns a list of all files
        files = new ArrayList<>();
        return listFiles(new File("C:\\MYXAMPP"));
    }

    private ArrayList<String> listFiles(File f) {
        System.out.println(f.getAbsolutePath());
        if (f.isFile()) {//if its a file
            files.add(f.getName());//add to files list
        } else {//otherwise--that is, its a folder
            for (File file : f.listFiles()) {//iterate throught the its contents
                listFiles(file);//test the same attributes
            }
        }
        return files;
    }

    ArrayList<String> listFolders() {//same as above but this time its for folders not files
        folders = new ArrayList<>();
        return listFolders(new File("C:\\MYXAMPP"));
    }

    private ArrayList<String> listFolders(File f) {
        if (f.isDirectory()) {
            folders.add(f.getName());
            for (File file : f.listFiles()) {
                listFolders(file);
            }
        }
        return folders;
    }

    HashSet<String> findDuplicateFiles() {
        duplicates = new HashSet<>();//initialise the hash map
        ArrayList<String> fl = listFiles();//get the list of all files
        for (int i = 0; i < fl.size(); i++) {//for each file
            for (int j = i; j < fl.size(); j++) {//for each succesive file
                if (fl.get(i).substring(0, 4).equalsIgnoreCase(fl.get(j).substring(0, 4))) {//compare the first 4 leatters of file names
                    duplicates.add(fl.get(i));//a match is found? thats a duplicate!
                }
            }
        }
        return duplicates;//return the list of duplicates
    }

    HashSet<String> findDuplicateFolders() {//same as above but this time its for folders not files
        duplicates = new HashSet<>();
        ArrayList<String> fl = listFolders();
        for (int i = 0; i < fl.size(); i++) {
            for (int j = i; j < fl.size(); j++) {
                if (fl.get(i).substring(0, 3).equalsIgnoreCase(fl.get(j).substring(0, 3))) {
                    duplicates.add(fl.get(i));
                }
            }
        }
        return duplicates;
    }
}
