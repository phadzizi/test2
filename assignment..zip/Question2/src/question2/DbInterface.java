/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question2;

import java.io.File;
import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author user
 */
public class DbInterface {
    // JDBC driver name and database URL

    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";//mySQL driver class
    static final String DB_URL = "jdbc:mysql://localhost/myroot";//database location and name
    static final String ROOT_FOLDER = "C:\\MYXAMPP";//folder for storing the files

    //  Database credentials
    static final String USER = "root";//database username
    static final String PASS = "";//db password
    static Connection conn = null;//db connection object
    static Statement stmt = null;//connection statement

    public static void main(String[] args) {
        dbConnection();//connect to database
        deepFiles(new File(ROOT_FOLDER));//capture files into the database
    }

    static void deepFiles(File f) {
        save(f.getName(), (f.isFile() ? "file" : "folder"));//save into the db
        System.out.println(f.getName());
        if (f.isDirectory()) {//if its a directory
            for (File file : f.listFiles()) {//iterate through its contents
                deepFiles(file);//recuring test
            }
        }
    }

    static boolean dbConnection() {//static initialisation block
        try {
            if (conn == null) {//if conn has not been initialised already
                // Register JDBC driver
                Class.forName("com.mysql.jdbc.Driver");

                // Open a connection
                conn = DriverManager.getConnection(DB_URL, USER, PASS);

                // Execute a query
                stmt = conn.createStatement();
            }
        } catch (SQLException se) {
            //Handle errors for JDBC
            se.printStackTrace();
        } catch (Exception e) {
            //Handle errors for Class.forName
            e.printStackTrace();
        }
        return conn != null;
    }//end initialisation block

    private static void save(String fname, String type) {
        String sql = "INSERT INTO `filesandfolders`(`fname`, `type`) "
                + "VALUES (\'" + fname + "\',\'" + type + "\')";//create the query for saving the data
        try {
            stmt.executeUpdate(sql);//execute the query
        } catch (SQLException ex) {
            Logger.getLogger(DbInterface.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    static void delete(String type, String parten) {
        String sql = "DELETE FROM `filesandfolders` WHERE (type=\'" + type
                + "\') AND (fname LIKE \'" + parten + "%\')";//create the query for deleting the data
        try {
            stmt.execute(sql);//execute the query
        } catch (SQLException ex) {
            System.out.println(sql);
            Logger.getLogger(DbInterface.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private static void nextWindow(String title, List<String> files, List<String> folders) {
        new NextW(title, files, folders).setVisible(true);//let the next window appear
    }

    static void goBack() {
        MainWindow.mainWindow.setVisible(true);//let main window appear
        NextW.nextW.setVisible(false);//and the current window disappear
    }

    public static void insertF() {
        deepFiles(new File(ROOT_FOLDER));//insert files into the db
        nextWindow("insert", new FilesandFolders().listFiles(), new FilesandFolders().listFolders());//show the inserted files in the window
    }

    public static void listContents() {//list all files and folders
        nextWindow("list", new FilesandFolders().listFiles(), new FilesandFolders().listFolders());
    }

    public static void deleteF() {//delete duplicates
        dbDeletedDisplayFiles();//delete duplicate files
        dbDeletedDisplayFolders();//delete duplicate folders
        nextWindow("deleted", new ArrayList(new FilesandFolders().findDuplicateFiles()),
                new ArrayList(new FilesandFolders().listFolders()));
    }

    public static void dbDeletedDisplayFiles() {
        for (String parttern : new FilesandFolders().findDuplicateFiles()) {//for all duplicate files
            delete("files", parttern.substring(0, 4));//delete from the database
        }
    }

    public static void dbDeletedDisplayFolders() {
        for (String parttern : new FilesandFolders().findDuplicateFolders()) {//for all duplicate folders
            delete("folders", parttern.substring(0, 3));//delete from the database
        }
    }
}
